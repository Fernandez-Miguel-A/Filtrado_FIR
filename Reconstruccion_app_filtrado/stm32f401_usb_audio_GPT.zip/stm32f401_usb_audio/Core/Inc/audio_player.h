#ifndef AUDIO_PLAYER_H
#define AUDIO_PLAYER_H

#include "stm32f4xx_hal.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum
{
    AUDIO_PLAYER_OK = 0,
    AUDIO_PLAYER_ERROR_ARGUMENT,
    AUDIO_PLAYER_ERROR_FILESYSTEM,
    AUDIO_PLAYER_ERROR_FILE,
    AUDIO_PLAYER_ERROR_WAV_FORMAT,
    AUDIO_PLAYER_ERROR_SAMPLE_RATE,
    AUDIO_PLAYER_ERROR_I2S,
    AUDIO_PLAYER_ERROR_DMA_OVERRUN
} AudioPlayer_Result;

typedef enum
{
    AUDIO_PLAYER_STOPPED = 0,
    AUDIO_PLAYER_PLAYING,
    AUDIO_PLAYER_ERROR
} AudioPlayer_State;

/* Inicializa el estado del reproductor. No inicia USB ni I2S. */
void AudioPlayer_Init(void);

/*
 * Abre un WAV desde FatFs, por ejemplo "0:/MUSIC.WAV".
 * Llamar solamente después de que USB Host haya detectado la clase MSC.
 */
AudioPlayer_Result AudioPlayer_Start(const char *fatfs_path);

/* Ejecutar repetidamente desde el while(1), nunca desde una interrupción. */
void AudioPlayer_Task(void);

/* Detiene I2S DMA y cierra el archivo si estaba abierto. */
void AudioPlayer_Stop(void);

AudioPlayer_State AudioPlayer_GetState(void);
AudioPlayer_Result AudioPlayer_GetLastResult(void);

#ifdef __cplusplus
}
#endif

#endif /* AUDIO_PLAYER_H */
