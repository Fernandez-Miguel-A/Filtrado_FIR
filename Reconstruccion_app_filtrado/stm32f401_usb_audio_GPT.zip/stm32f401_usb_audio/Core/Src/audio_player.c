#include "audio_player.h"

#include "ff.h"
#include <string.h>

/*
 * Proyecto base: STM32F401RE + USB Host MSC/FatFs + I2S2 + DMA circular.
 * Formato soportado: WAV RIFF PCM, 16 bits, 1 o 2 canales, 48 kHz.
 */

#ifndef AUDIO_SAMPLE_RATE
#define AUDIO_SAMPLE_RATE          48000U
#endif

#define AUDIO_CHANNELS_MAX         2U
#define AUDIO_BYTES_PER_SAMPLE     2U
#define AUDIO_FRAMES_PER_HALF      1024U
#define AUDIO_HALF_WORDS           (AUDIO_FRAMES_PER_HALF * AUDIO_CHANNELS_MAX)
#define AUDIO_DMA_WORDS            (2U * AUDIO_HALF_WORDS)
#define AUDIO_RAW_BYTES            (AUDIO_FRAMES_PER_HALF * AUDIO_CHANNELS_MAX * AUDIO_BYTES_PER_SAMPLE)

/* DMA1 Stream4 / Channel0: solicitud SPI2_TX, usada por I2S2 TX. */
extern I2S_HandleTypeDef hi2s2;

/* FATFS_LinkDriver() normalmente asigna "0:" al primer volumen USB. */
#ifndef AUDIO_FATFS_DRIVE
#define AUDIO_FATFS_DRIVE          "0:"
#endif

static FATFS s_fatfs;
static FIL   s_file;
static uint8_t s_file_open = 0U;

/*
 * DMA envía la matriz completa en modo circular:
 *   [0 .. AUDIO_HALF_WORDS-1]                 primera mitad
 *   [AUDIO_HALF_WORDS .. AUDIO_DMA_WORDS-1]   segunda mitad
 * Cada palabra DMA es un halfword I2S de 16 bits.
 */
#if defined(__GNUC__)
__attribute__((aligned(4)))
#endif
static uint16_t s_i2s_dma[AUDIO_DMA_WORDS];
static uint8_t  s_raw[AUDIO_RAW_BYTES];

static uint8_t  s_channels = 0U;
static uint16_t s_block_align = 0U;
static uint32_t s_data_remaining = 0U;

static volatile uint8_t s_dma_flags = 0U;
static volatile uint8_t s_stop_requested = 0U;
static volatile uint8_t s_overrun = 0U;
static volatile uint8_t s_dma_running = 0U;
static volatile uint8_t s_half_eof[2] = { 0U, 0U };
static volatile uint8_t s_refilling[2] = { 0U, 0U };

static AudioPlayer_State  s_state = AUDIO_PLAYER_STOPPED;
static AudioPlayer_Result s_last_result = AUDIO_PLAYER_OK;

#define DMA_FLAG_FIRST_HALF   (1U << 0)
#define DMA_FLAG_SECOND_HALF  (1U << 1)

static uint16_t read_u16_le(const uint8_t *p)
{
    return (uint16_t)((uint16_t)p[0] | ((uint16_t)p[1] << 8));
}

static uint32_t read_u32_le(const uint8_t *p)
{
    return ((uint32_t)p[0]) |
           ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) |
           ((uint32_t)p[3] << 24);
}

static FRESULT read_exact(FIL *file, uint8_t *buffer, UINT length)
{
    UINT bytes_read = 0U;
    FRESULT result = f_read(file, buffer, length, &bytes_read);

    if (result != FR_OK)
    {
        return result;
    }

    return (bytes_read == length) ? FR_OK : FR_INT_ERR;
}

static AudioPlayer_Result parse_wav(FIL *file)
{
    uint8_t riff_header[12];
    uint8_t chunk_header[8];
    uint8_t fmt[16];
    FSIZE_t file_size;
    FSIZE_t data_offset = 0U;
    uint32_t data_size = 0U;
    uint32_t sample_rate = 0U;
    uint16_t audio_format = 0U;
    uint16_t channels = 0U;
    uint16_t bits_per_sample = 0U;
    uint16_t block_align = 0U;
    uint8_t fmt_found = 0U;
    uint8_t data_found = 0U;

    if (read_exact(file, riff_header, sizeof(riff_header)) != FR_OK)
    {
        return AUDIO_PLAYER_ERROR_WAV_FORMAT;
    }

    if ((memcmp(&riff_header[0], "RIFF", 4U) != 0) ||
        (memcmp(&riff_header[8], "WAVE", 4U) != 0))
    {
        return AUDIO_PLAYER_ERROR_WAV_FORMAT;
    }

    file_size = f_size(file);

    /* Recorre chunks RIFF. Se admiten chunks desconocidos antes/después de fmt/data. */
    while ((f_tell(file) <= file_size) && ((file_size - f_tell(file)) >= 8U))
    {
        FSIZE_t payload_offset;
        FSIZE_t next_chunk;
        uint32_t chunk_size;

        if ((file_size - f_tell(file)) < 8U)
        {
            break;
        }

        if (read_exact(file, chunk_header, sizeof(chunk_header)) != FR_OK)
        {
            return AUDIO_PLAYER_ERROR_WAV_FORMAT;
        }

        chunk_size = read_u32_le(&chunk_header[4]);
        payload_offset = f_tell(file);

        if (payload_offset > file_size || (FSIZE_t)chunk_size > (file_size - payload_offset))
        {
            return AUDIO_PLAYER_ERROR_WAV_FORMAT;
        }

        if (memcmp(&chunk_header[0], "fmt ", 4U) == 0)
        {
            if (chunk_size < sizeof(fmt))
            {
                return AUDIO_PLAYER_ERROR_WAV_FORMAT;
            }

            if (read_exact(file, fmt, sizeof(fmt)) != FR_OK)
            {
                return AUDIO_PLAYER_ERROR_WAV_FORMAT;
            }

            audio_format   = read_u16_le(&fmt[0]);
            channels       = read_u16_le(&fmt[2]);
            sample_rate    = read_u32_le(&fmt[4]);
            block_align    = read_u16_le(&fmt[12]);
            bits_per_sample = read_u16_le(&fmt[14]);
            fmt_found = 1U;
        }
        else if ((memcmp(&chunk_header[0], "data", 4U) == 0) && (data_found == 0U))
        {
            data_offset = payload_offset;
            data_size = chunk_size;
            data_found = 1U;
        }

        next_chunk = payload_offset + (FSIZE_t)chunk_size + (FSIZE_t)(chunk_size & 1U);
        if (next_chunk > file_size)
        {
            return AUDIO_PLAYER_ERROR_WAV_FORMAT;
        }

        if (f_lseek(file, next_chunk) != FR_OK)
        {
            return AUDIO_PLAYER_ERROR_WAV_FORMAT;
        }

        if ((fmt_found != 0U) && (data_found != 0U))
        {
            break;
        }
    }

    if ((fmt_found == 0U) || (data_found == 0U))
    {
        return AUDIO_PLAYER_ERROR_WAV_FORMAT;
    }

    if (audio_format != 1U) /* 1 = PCM sin compresión */
    {
        return AUDIO_PLAYER_ERROR_WAV_FORMAT;
    }

    if ((channels != 1U) && (channels != 2U))
    {
        return AUDIO_PLAYER_ERROR_WAV_FORMAT;
    }

    if (bits_per_sample != 16U)
    {
        return AUDIO_PLAYER_ERROR_WAV_FORMAT;
    }

    if (sample_rate != AUDIO_SAMPLE_RATE)
    {
        return AUDIO_PLAYER_ERROR_SAMPLE_RATE;
    }

    if (block_align != (uint16_t)(channels * AUDIO_BYTES_PER_SAMPLE))
    {
        return AUDIO_PLAYER_ERROR_WAV_FORMAT;
    }

    if ((data_size == 0U) || ((data_size % block_align) != 0U))
    {
        return AUDIO_PLAYER_ERROR_WAV_FORMAT;
    }

    if (f_lseek(file, data_offset) != FR_OK)
    {
        return AUDIO_PLAYER_ERROR_WAV_FORMAT;
    }

    s_channels = (uint8_t)channels;
    s_block_align = block_align;
    s_data_remaining = data_size;

    return AUDIO_PLAYER_OK;
}

/* Rellena una mitad ya liberada por DMA. Se llama solo desde contexto normal. */
static AudioPlayer_Result fill_half(uint8_t half_index)
{
    uint16_t *destination;
    uint32_t frames_to_read;
    uint32_t bytes_to_read;
    uint32_t frames_read;
    UINT bytes_read = 0U;
    FRESULT fs_result;
    uint32_t i;

    if (half_index > 1U)
    {
        return AUDIO_PLAYER_ERROR_ARGUMENT;
    }

    destination = &s_i2s_dma[(uint32_t)half_index * AUDIO_HALF_WORDS];
    memset(destination, 0, AUDIO_HALF_WORDS * sizeof(uint16_t));

    if (s_data_remaining == 0U)
    {
        s_half_eof[half_index] = 1U;
        return AUDIO_PLAYER_OK;
    }

    frames_to_read = s_data_remaining / s_block_align;
    if (frames_to_read > AUDIO_FRAMES_PER_HALF)
    {
        frames_to_read = AUDIO_FRAMES_PER_HALF;
    }

    bytes_to_read = frames_to_read * s_block_align;
    fs_result = f_read(&s_file, s_raw, (UINT)bytes_to_read, &bytes_read);

    if ((fs_result != FR_OK) || (bytes_read != bytes_to_read))
    {
        s_half_eof[half_index] = 1U;
        s_last_result = AUDIO_PLAYER_ERROR_FILE;
        return AUDIO_PLAYER_ERROR_FILE;
    }

    s_data_remaining -= bytes_read;
    frames_read = bytes_read / s_block_align;

    if (s_channels == 2U)
    {
        for (i = 0U; i < frames_read; ++i)
        {
            uint32_t in = i * 4U;
            uint32_t out = i * 2U;
            destination[out]     = read_u16_le(&s_raw[in]);
            destination[out + 1] = read_u16_le(&s_raw[in + 2U]);
        }
    }
    else /* Mono: duplica cada muestra en L y R. */
    {
        for (i = 0U; i < frames_read; ++i)
        {
            uint16_t sample = read_u16_le(&s_raw[i * 2U]);
            destination[i * 2U] = sample;
            destination[i * 2U + 1U] = sample;
        }
    }

    /* La parte no utilizada de la última mitad queda en cero (silencio). */
    s_half_eof[half_index] = (s_data_remaining == 0U) ? 1U : 0U;
    return AUDIO_PLAYER_OK;
}

static void close_file(void)
{
    if (s_file_open != 0U)
    {
        (void)f_close(&s_file);
        s_file_open = 0U;
    }
}

void AudioPlayer_Init(void)
{
    s_file_open = 0U;
    s_channels = 0U;
    s_block_align = 0U;
    s_data_remaining = 0U;
    s_dma_flags = 0U;
    s_stop_requested = 0U;
    s_overrun = 0U;
    s_dma_running = 0U;
    s_half_eof[0] = 0U;
    s_half_eof[1] = 0U;
    s_refilling[0] = 0U;
    s_refilling[1] = 0U;
    s_state = AUDIO_PLAYER_STOPPED;
    s_last_result = AUDIO_PLAYER_OK;
    memset(s_i2s_dma, 0, sizeof(s_i2s_dma));
}

AudioPlayer_Result AudioPlayer_Start(const char *fatfs_path)
{
    AudioPlayer_Result result;

    if ((fatfs_path == NULL) || (fatfs_path[0] == '\0'))
    {
        s_last_result = AUDIO_PLAYER_ERROR_ARGUMENT;
        return s_last_result;
    }

    AudioPlayer_Stop();
    s_last_result = AUDIO_PLAYER_OK;

    /* Monta el volumen USB (solo después de HOST_USER_CLASS_ACTIVE). */
    if (f_mount(&s_fatfs, AUDIO_FATFS_DRIVE, 1U) != FR_OK)
    {
        s_state = AUDIO_PLAYER_ERROR;
        s_last_result = AUDIO_PLAYER_ERROR_FILESYSTEM;
        return s_last_result;
    }

    if (f_open(&s_file, fatfs_path, FA_READ) != FR_OK)
    {
        s_state = AUDIO_PLAYER_ERROR;
        s_last_result = AUDIO_PLAYER_ERROR_FILE;
        return s_last_result;
    }
    s_file_open = 1U;

    result = parse_wav(&s_file);
    if (result != AUDIO_PLAYER_OK)
    {
        close_file();
        s_state = AUDIO_PLAYER_ERROR;
        s_last_result = result;
        return result;
    }

    s_dma_flags = 0U;
    s_stop_requested = 0U;
    s_overrun = 0U;
    s_half_eof[0] = 0U;
    s_half_eof[1] = 0U;
    s_refilling[0] = 0U;
    s_refilling[1] = 0U;

    if (fill_half(0U) != AUDIO_PLAYER_OK || fill_half(1U) != AUDIO_PLAYER_OK)
    {
        close_file();
        s_state = AUDIO_PLAYER_ERROR;
        s_last_result = AUDIO_PLAYER_ERROR_FILE;
        return s_last_result;
    }

    s_dma_running = 1U;
    if (HAL_I2S_Transmit_DMA(&hi2s2, s_i2s_dma, AUDIO_DMA_WORDS) != HAL_OK)
    {
        s_dma_running = 0U;
        close_file();
        s_state = AUDIO_PLAYER_ERROR;
        s_last_result = AUDIO_PLAYER_ERROR_I2S;
        return s_last_result;
    }

    s_state = AUDIO_PLAYER_PLAYING;
    s_last_result = AUDIO_PLAYER_OK;
    return AUDIO_PLAYER_OK;
}

void AudioPlayer_Task(void)
{
    uint8_t flags;
    uint32_t primask;

    if (s_state != AUDIO_PLAYER_PLAYING)
    {
        return;
    }

    if (s_overrun != 0U)
    {
        AudioPlayer_Stop();
        s_state = AUDIO_PLAYER_ERROR;
        s_last_result = AUDIO_PLAYER_ERROR_DMA_OVERRUN;
        return;
    }

    if (s_stop_requested != 0U)
    {
        AudioPlayer_Stop();
        if (s_last_result != AUDIO_PLAYER_OK)
        {
            s_state = AUDIO_PLAYER_ERROR;
        }
        return;
    }

    /* Toma y limpia las marcas de DMA de forma atómica. */
    primask = __get_PRIMASK();
    __disable_irq();
    flags = s_dma_flags;
    s_dma_flags = 0U;
    if ((flags & DMA_FLAG_FIRST_HALF) != 0U)
    {
        s_refilling[0] = 1U;
    }
    if ((flags & DMA_FLAG_SECOND_HALF) != 0U)
    {
        s_refilling[1] = 1U;
    }
    __set_PRIMASK(primask);

    /* El orden es importante si ambas mitades quedaron pendientes. */
    if ((flags & DMA_FLAG_FIRST_HALF) != 0U)
    {
        if (fill_half(0U) != AUDIO_PLAYER_OK)
        {
            s_stop_requested = 1U;
        }
        s_refilling[0] = 0U;
    }

    if ((flags & DMA_FLAG_SECOND_HALF) != 0U)
    {
        if (fill_half(1U) != AUDIO_PLAYER_OK)
        {
            s_stop_requested = 1U;
        }
        s_refilling[1] = 0U;
    }
}

void AudioPlayer_Stop(void)
{
    if (s_dma_running != 0U)
    {
        (void)HAL_I2S_DMAStop(&hi2s2);
        s_dma_running = 0U;
    }

    s_dma_flags = 0U;
    s_stop_requested = 0U;
    s_overrun = 0U;
    s_refilling[0] = 0U;
    s_refilling[1] = 0U;
    close_file();

    if (s_state != AUDIO_PLAYER_ERROR)
    {
        s_state = AUDIO_PLAYER_STOPPED;
    }
}

AudioPlayer_State AudioPlayer_GetState(void)
{
    return s_state;
}

AudioPlayer_Result AudioPlayer_GetLastResult(void)
{
    return s_last_result;
}

/* Estas callbacks se ejecutan desde la interrupción DMA. No usar FatFs aquí. */
void HAL_I2S_TxHalfCpltCallback(I2S_HandleTypeDef *hi2s)
{
    if ((hi2s == &hi2s2) && (s_dma_running != 0U))
    {
        /* Al terminar A, DMA comienza B: B debe estar lista para transmitirse. */
        if (s_refilling[1] != 0U)
        {
            s_overrun = 1U;
        }

        if (s_half_eof[0] != 0U)
        {
            s_stop_requested = 1U;
        }
        else if ((s_dma_flags & DMA_FLAG_FIRST_HALF) != 0U)
        {
            s_overrun = 1U;
        }
        else
        {
            s_dma_flags |= DMA_FLAG_FIRST_HALF;
        }
    }
}

void HAL_I2S_TxCpltCallback(I2S_HandleTypeDef *hi2s)
{
    if ((hi2s == &hi2s2) && (s_dma_running != 0U))
    {
        /* Al terminar B, DMA comienza A: A debe estar lista para transmitirse. */
        if (s_refilling[0] != 0U)
        {
            s_overrun = 1U;
        }

        if (s_half_eof[1] != 0U)
        {
            s_stop_requested = 1U;
        }
        else if ((s_dma_flags & DMA_FLAG_SECOND_HALF) != 0U)
        {
            s_overrun = 1U;
        }
        else
        {
            s_dma_flags |= DMA_FLAG_SECOND_HALF;
        }
    }
}

void HAL_I2S_ErrorCallback(I2S_HandleTypeDef *hi2s)
{
    if (hi2s == &hi2s2)
    {
        s_stop_requested = 1U;
        s_last_result = AUDIO_PLAYER_ERROR_I2S;
    }
}
