# Reproductor WAV USB Host → I2S DMA para STM32F401RE

Este paquete contiene el módulo de reproducción que se agrega a un proyecto STM32CubeIDE/HAL. Usa:

- USB OTG FS en modo Host.
- USB Mass Storage Class (pendrive).
- FatFs para abrir y leer archivos.
- I2S2 en modo Master Transmit.
- DMA1 Stream4 / Channel0 en modo circular.
- DAC I2S externo PCM5102A (recomendado).

## 1. Formato de audio admitido

El código admite WAV RIFF sin compresión (PCM):

- 48 000 muestras por segundo.
- 16 bits por muestra.
- Mono o estéreo.
- El audio mono se duplica hacia L y R.
- Otros formatos (MP3, WAV 24-bit, WAV 8-bit, 44.1 kHz, etc.) no se decodifican.

Prepara el pendrive FAT32 con un archivo llamado `MUSIC.WAV` en el directorio raíz.

## 2. Resolución del DAC

El STM32F401RE no incluye un DAC analógico interno. Tiene I2S para enviar audio digital, de modo que la salida analógica se obtiene con un DAC externo I2S. El módulo PCM5102A es una opción sencilla: recibe BCK, LRCK y DIN, y entrega salidas analógicas L/R. El PCM5102A puede generar su reloj interno a partir de BCK, por lo que permite el enlace I2S de tres señales; en el módulo concreto, configura el modo I2S y la opción PLL según su placa.

La salida del PCM5102A es de nivel de línea; para un parlante pasivo necesitas un amplificador de potencia. No conectes un parlante directamente a LOUT/ROUT.

## 3. Cableado sugerido

### I2S2 hacia PCM5102A

| STM32F401RE | Señal | PCM5102A |
|---|---|---|
| PB13 | I2S2_CK / BCK | BCK |
| PB12 | I2S2_WS / LRCK | LRCK / LCK |
| PB15 | I2S2_SD | DIN |
| GND | Referencia | GND |
| 3V3 o alimentación indicada por el módulo | Alimentación | VCC |
| — | Reloj MCLK no usado | SCK a GND, si el módulo usa PLL interno |

Algunos módulos PCM5102A incorporan reguladores y resistencias de configuración; verifica su esquema antes de aplicar alimentación. No conectes las salidas analógicas del DAC a un GPIO.

### USB Host FS

| STM32F401RE | Señal USB |
|---|---|
| PA11 | USB_DM / D− |
| PA12 | USB_DP / D+ |
| PA9 | USB_VBUS sense |
| PA10 | USB_ID |
| GND | GND USB |
| Fuente externa de 5 V con limitación de corriente | VBUS del conector USB-A |

El conector USB del ST-LINK de la Nucleo no es el puerto USB Host del microcontrolador. Debes cablear PA11/PA12 a un conector USB-A host y proporcionar VBUS de 5 V mediante un interruptor de alimentación USB con limitación de corriente y protección. No alimentes VBUS directamente desde un pin GPIO. Para un puerto A host, ID debe quedar configurado como A-device (normalmente a GND según el cableado OTG usado). La detección VBUS debe respetar el circuito de referencia de ST.

## 4. Configuración en STM32CubeMX

Selecciona el MCU/placa STM32F401RE y configura:

### Clock

- SYSCLK: hasta 84 MHz.
- USB OTG FS: reloj de 48 MHz exactos desde PLLQ.
- Activa PLLI2S y configura I2S2 para 48 kHz. Comprueba el LRCK real con osciloscopio o analizador lógico; el DAC debe recibir 48 kHz.

### USB Host

- USB_OTG_FS: Host Only.
- Middleware USB_HOST: habilitado.
- Clase: Mass Storage (MSC).
- FatFs: habilitar el volumen USB Disk.
- Generar la función de proceso `MX_USB_HOST_Process()` y el callback de estado de aplicación.
- Enlazar el driver USB a FatFs (`FATFS_LinkDriver(&USBH_Driver, USBHPath)`) mediante la configuración generada.

La aplicación debe esperar `HOST_USER_CLASS_ACTIVE` / `APPLICATION_READY` antes de llamar a `AudioPlayer_Start()`.

### I2S2

- Modo: Master Transmit.
- Standard: Philips I2S.
- Data format: 16 Bits.
- Audio frequency: 48 kHz.
- MCLK output: Disabled (para PCM5102A en modo PLL de 3 cables).
- Clock polarity: Low.
- Pines: PB13 = CK, PB12 = WS, PB15 = SD.

### DMA de I2S2 TX

- Controller: DMA1.
- Stream: Stream4.
- Channel: Channel0 (SPI2_TX / I2S2 TX).
- Direction: Memory to Peripheral.
- Peripheral increment: Disabled.
- Memory increment: Enabled.
- Peripheral alignment: Half Word.
- Memory alignment: Half Word.
- Mode: Circular.
- Priority: Very High.
- FIFO: Disabled (direct mode).

En NVIC habilita la interrupción de DMA1 Stream4. CubeMX debe enlazar el DMA al handle I2S2 TX (`__HAL_LINKDMA`).

## 5. Añadir los archivos

Copia:

- `Core/Inc/audio_player.h`
- `Core/Src/audio_player.c`

al proyecto CubeIDE. Asegúrate de que el proyecto incluye FatFs (`ff.h`) y el handle I2S `hi2s2`.

El módulo usa `AUDIO_FATFS_DRIVE "0:"`. Si `FATFS_LinkDriver()` asigna otro volumen, cambia ese define en `audio_player.c`.

## 6. Integración en main.c

Incluye:

```c
#include "audio_player.h"
#include "usb_host.h"
#include "i2s.h"       // o el header generado donde se declara hi2s2
```

Después de `MX_USB_HOST_Init()`, `MX_FATFS_Init()` y `MX_I2S2_Init()`:

```c
AudioPlayer_Init();
```

En el bucle principal, mantén el proceso USB ejecutándose. Ejemplo típico de CubeMX:

```c
static uint8_t music_started = 0;

while (1)
{
    MX_USB_HOST_Process();

    if ((Appli_state == APPLICATION_READY) && (music_started == 0U))
    {
        if (AudioPlayer_Start("0:/MUSIC.WAV") == AUDIO_PLAYER_OK)
        {
            music_started = 1U;
        }
    }

    if (Appli_state == APPLICATION_DISCONNECT)
    {
        AudioPlayer_Stop();
        music_started = 0U;
    }

    AudioPlayer_Task();
}
```

Los nombres `Appli_state`, `APPLICATION_READY`, `APPLICATION_DISCONNECT` pueden variar según la versión del generador CubeMX. Usa los identificadores presentes en tu `usb_host.c`/`usb_host.h`. Si el archivo se desconecta durante la reproducción, detén el DMA antes de volver a montar el volumen.

No llames `AudioPlayer_Start()`, `AudioPlayer_Task()` ni funciones FatFs desde una ISR. El módulo ya mantiene las callbacks I2S/DMA: no declares una segunda implementación de `HAL_I2S_TxHalfCpltCallback`, `HAL_I2S_TxCpltCallback` o `HAL_I2S_ErrorCallback` en otro archivo; integra su contenido si ya existen.

## 7. Cómo funciona el doble búfer

` s_i2s_dma[] ` contiene dos mitades de `AUDIO_HALF_WORDS` halfwords:

1. Se cargan ambas mitades desde el WAV antes de iniciar el DMA.
2. `HAL_I2S_TxHalfCpltCallback()` indica que terminó la primera mitad; el DMA ya está transmitiendo la segunda.
3. `AudioPlayer_Task()` lee el siguiente bloque de FatFs y vuelve a llenar la primera mitad.
4. `HAL_I2S_TxCpltCallback()` indica que terminó la segunda mitad; el DMA vuelve a la primera.
5. `AudioPlayer_Task()` rellena la segunda mitad.

Cada mitad representa 1024 cuadros estéreo: `1024 / 48000 = 21,33 ms`. Por eso `AudioPlayer_Task()` debe ejecutarse con regularidad y cada lectura del pendrive debe terminar antes de que el DMA vuelva a esa mitad. Las callbacks no acceden a FatFs. Si detecta que el programa no atendió a tiempo una mitad, detiene la reproducción y reporta `AUDIO_PLAYER_ERROR_DMA_OVERRUN` en lugar de continuar con datos corruptos.

## 8. Consideraciones de la versión de USB Host/FatFs

El driver USB MSC/FatFs de ST depende de la versión de STM32CubeF4. En el modo standalone, las operaciones de lectura de disco pueden ser bloqueantes; verifica que la implementación `usbh_diskio.c` de tu paquete Cube atienda el estado de la operación USB durante `disk_read()`. La aplicación debe mantener `MX_USB_HOST_Process()` en el bucle principal, fuera de callbacks e interrupciones.

Este paquete aporta el motor WAV/doble-búfer y los puntos de integración. CubeMX debe generar los archivos específicos de reloj, USB Host, FatFs, GPIO, I2S y DMA para la versión instalada del STM32CubeF4.
